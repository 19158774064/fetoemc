package com.fetoemc.registry;

import com.fetoemc.FetoemcMod;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

/**
 * 创造模式物品栏分类注册
 */
public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(FetoemcMod.MOD_ID, Registries.f_279569_);

    public static final RegistrySupplier<CreativeModeTab> FEMC_TAB = TABS.register("femc_tab",
            () -> CreativeModeTab.m_257815_(CreativeModeTab.Row.TOP, 0)
                    .m_257941_(Component.m_237115_("itemGroup." + FetoemcMod.MOD_ID + ".femc_tab"))
                    .m_257737_(() -> new ItemStack(ModBlocks.FEMC_CONVERTER.get()))
                    .m_257501_((parameters, output) -> {
                        output.m_246326_(ModBlocks.FEMC_CONVERTER.get());
                    })
                    .m_257652_()
    );

    public static void register() {
        TABS.register();
    }

    private ModCreativeTabs() {}
}